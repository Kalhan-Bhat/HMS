const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

const app = express();
const port = process.env.PORT || 3002;
// Database connection
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: 'hospital_management', // Use the specific database name
  multipleStatements: true
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log("Connected to MySQL database");
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Helper function for database queries
const query = (sql, params) => {
  return new Promise((resolve, reject) => {
    db.query(sql, params, (error, results) => {
      if (error) reject(error);
      else resolve(results);
    });
  });
};
// Routes
// Register a new patient
app.post('/register/patient', async (req, res) => {
  const { name, sex, address, Pdetails, date_admitted, date_discharged, contact_no } = req.body;
  try {
    await query(
      'INSERT INTO Patient (name, sex, address, Pdetails, date_admitted, date_discharged, contact_no) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [name, sex, address, Pdetails, date_admitted, date_discharged, contact_no]
    );
    res.json({ message: 'Patient registered successfully' });
  } catch (error) {
    console.error('Error registering patient:', error.message);
    res.status(500).json({ error: 'Registration failed', details: error.message });
  }
});
// Register a new doctor
app.post('/register/doctor', async (req, res) => {
  const { name, specialization, contact, salary, type } = req.body;
  try {
    await query(
      'INSERT INTO Doctor (name, specialization, contact, salary, type) VALUES (?, ?, ?, ?, ?)',
      [name, specialization, contact, salary, type]
    );
    res.json({ message: 'Doctor registered successfully' });
  } catch (error) {
    console.error('Error registering doctor:', error.message);
    res.status(500).json({ error: 'Registration failed', details: error.message });
  }
});
// Register a new nurse
app.post('/register/nurse', async (req, res) => {
  const { name, contact, department } = req.body;
  try {
    await query(
      'INSERT INTO Nurse (name, contact, department) VALUES (?, ?, ?)',
      [name, contact, department]
    );
    res.json({ message: 'Nurse registered successfully' });
  } catch (error) {
    console.error('Error registering nurse:', error.message);
    res.status(500).json({ error: 'Registration failed', details: error.message });
  }
});
// Add a new room
app.post('/add/room', async (req, res) => {
  const { room_id, room_type } = req.body;
  try {
    await query(
      'INSERT INTO Room (room_id, room_type) VALUES (?, ?)',
      [room_id, room_type]
    );
    res.json({ message: 'Room added successfully' });
  } catch (error) {
    console.error('Error adding room:', error.message);
    res.status(500).json({ error: 'Failed to add room', details: error.message });
  }
});
// Add a new medicine
app.post('/add/medicine', async (req, res) => {
  const { name, price, quantity, code } = req.body;
  try {
    await query(
      'INSERT INTO Medicine (name, price, quantity, code) VALUES (?, ?, ?, ?)',
      [name, price, quantity, code]
    );
    res.json({ message: 'Medicine added successfully' });
  } catch (error) {
    console.error('Error adding medicine:', error.message);
    res.status(500).json({ error: 'Failed to add medicine', details: error.message });
  }
});
// Fetch all patients
app.get('/patients', async (req, res) => {
  try {
    const patients = await query('SELECT * FROM Patient');
    res.json(patients);
  } catch (error) {
    console.error('Error fetching patients:', error.message);
    res.status(500).json({ error: 'Failed to fetch patients' });
  }
});
// Fetch all doctors
app.get('/doctors', async (req, res) => {
  try {
    const doctors = await query('SELECT * FROM Doctor');
    res.json(doctors);
  } catch (error) {
    console.error('Error fetching doctors:', error.message);
    res.status(500).json({ error: 'Failed to fetch doctors' });
  }
});
// Fetch all nurses
app.get('/nurses', async (req, res) => {
  try {
    const nurses = await query('SELECT * FROM Nurse');
    res.json(nurses);
  } catch (error) {
    console.error('Error fetching nurses:', error.message);
    res.status(500).json({ error: 'Failed to fetch nurses' });
  }
});
// Fetch all rooms
app.get('/rooms', async (req, res) => {
  try {
    const rooms = await query('SELECT * FROM Room');
    res.json(rooms);
  } catch (error) {
    console.error('Error fetching rooms:', error.message);
    res.status(500).json({ error: 'Failed to fetch rooms' });
  }
});
// Fetch all medicines
app.get('/medicines', async (req, res) => {
  try {
    const medicines = await query('SELECT * FROM Medicine');
    res.json(medicines);
  } catch (error) {
    console.error('Error fetching medicines:', error.message);
    res.status(500).json({ error: 'Failed to fetch medicines' });
  }
});
// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

module.exports = app;
